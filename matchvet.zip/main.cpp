/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

bool verifica (int v[],int v2[],int v3[],int n,int check)
{
    int i=0;
    bool risultato;
    
        while (i<n){
        check=v[i];
        if (check!=v2[i] or check!=v3[i])
        {
            risultato=false;
            i=n;
        }
        else
        {
        risultato=true;
        i++;
        }
    }
    return risultato;
    
}

int main()
{
    int n=4;
    int v1[n]={5,3,3,6};
    int v2[n]={5,3,4,6};
    int v3[n]={5,3,3,6};
    int check;
    bool uguali;
    
uguali=verifica(v1,v2,v3,n,check);

if (uguali==true)
cout<<"I vettori sono uguali nell'ordine e contenuto";

else
cout<<"I vettori sono diversi";
    
    
    return 0;
}
