/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

    string strvar (string date,string value,int *index) //Funzione per inserire e trasformare in un formato valido le stringhe in var Giorno
    {
        int cont=0;
            while ((*index<date.length()) and (date[*index]!='/'))
        {
            value=value+date[*index];
            cont++;
            *index=*index+1;
        }
        *index=*index+1;
        if (cont<2)
            {
            value="0"+value;
            cont=0;
            }
        return value;
    }
    
    string fyear (string date,string year,int *index) //Funzione per inserire il valore nella var Anno
    {
        while (*index<date.length())
        {
        year=year+date[*index];
        *index=*index+1;
        }
    return year;
    }
    
    string monthstr (string mat[2][12],string month) //Funzione per la conversione da stringa numerica del mese a nome del mese
    {   
            int r=2;
            int c=12;
            int z=0;
            int j=0;
            while ((z<r) and (j<c))
        {
        if (mat[z][j]==month) //Se il testo nella matrice è uguale a quello in mese..
            {
            z=z+1;
            month=mat[z][j]; //mese=testo della matrice
            z=r; //exit dal while
            }
        j++;
        }
        return month;
    }
int main()
{
    string listamesi[2][12]={{"01","02","03","04","05","06","07","08","09","10","11","12"},{"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"}};
    //^Dichiarazione matrice^
    string data="1/9/23";
    string giorno;
    string mese;
    string anno;
    int num; //Variabile per convertire da stringa a numero la var Anno
    int i=0;
    
    giorno=strvar(data,giorno,&i); // Richiamo delle varie funzioni,conservando la posizione della I
    mese=strvar(data,mese,&i);
    anno=fyear(data,anno,&i);
    mese=monthstr(listamesi,mese);
    num=stoi(anno);
    
    if (num<=23) //Se il valore è inferiore al 23 l'anno è precedente il 2000 e si aggiunge 19,altrimenti si aggiunge 20
    anno="20"+anno;
    else
    anno="19"+anno;
    
    cout<<giorno+'/'+mese+'/'+anno; //Stampa Data

    return 0;
    
}





