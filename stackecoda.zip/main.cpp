/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int check() //Controllo su input 
{
    int temp;
    cin>>temp;
    while ((cin.fail()) or (temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Invalid input"<<endl;
        cin>>temp;
    }
    return temp;
}

void put(int array[],int dim,int head,int numstack) //funzione put negli stack
{   
    int numero;
    while (head<dim) 
    {
        cout<<"Inserisci un valore in posizione "<<head<<" per lo stack numero "<<numstack<<endl;
        numero=check();
        array[head]=numero;
        head=head+1;
    }
}

void showstack(int array[],int dim,int head,int numstack) //funzione visualizza stack
{
    cout<<"I numeri nello stack ~"<<numstack<<"~ sono i seguenti"<<endl;
    cout<<"<---- Testa ->";
    for (head=dim-1;head>=0;head--)
    {
        cout<<" | "<<array[head]<<" | ";
    }
    cout<<" <---"<<endl;
}

void showbuffer(int array[],int dim,int head) //funzione visualizza coda
{
    cout<<"I numeri nella coda sono i seguenti"<<endl;
    cout<<"----> Coda ->";
    for (head=dim-1;head>=0;head--)
    {
        cout<<" | "<<array[head]<<" | ";
    }
    cout<<"<-Testa --->"<<endl;
}

void insert(int array[],int dim, int buffer[],int dim2,int head,int *headbuffer) //Funzione insert
{
    for (head=dim-1;head>=0;head--) //Per l'inserimento si parte dalla testa dello stack e si memorizza all'inizio della coda
    {
        buffer[*headbuffer]=array[head];
        *headbuffer=*headbuffer+1; //poi la coda incrementa
    }
}
int main()
{
    int n1,n2,n3;
    int testa=0;
//Inseriamo la dimensione dei due stack
    cout<<"Inserisci la dimensione del primo stack"<<endl;
    n1=check();
    cout<<"Inserisci la dimensione del secondo stack"<<endl;
    n2=check();
    n3=n1+n2;
    cout<<"La coda sarà di dimensioni "<<n3<<endl;
//Creiamo 2 stack e la coda
    int stack1[n1];
    int stack2[n2];
    int coda[n3];
//Input del primo stack
    put(stack1,n1,testa,1);
//Input secondo stack
    put(stack2,n2,testa,2);
//Visualizza i due stack
    showstack(stack1,n1,testa,1);
    showstack(stack2,n2,testa,2);
//Creiamo un puntatore per la coda
    int testabuffer=0;
//Inseriamo i valori degli stack
    insert(stack1,n1,coda,n3,testa,&testabuffer);
    insert(stack2,n2,coda,n3,testa,&testabuffer);
//Visualizziamo a schermo
    showbuffer(coda,n3,testa);

return 0;
}