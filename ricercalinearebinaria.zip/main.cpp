/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <ctime>
using namespace std;

void scambia(int vet[], int dim, int pos)
{
    int temp = 0;

    temp = vet[pos];
    vet[pos] = vet[pos + 1];
    vet[pos + 1] = temp;
}

void bubblesort(int dim, int vet[])
{
    for (int j = 0; j < dim - 1; j++)
    {
        for (int i = 0; i < dim - j - 1; i++)
        {
            if (vet[i] > vet[i + 1])
            {
                scambia(vet, dim, i);
            }
        }
    }
}

void randomizzavet(int v[], int dim)
{
    srand(time(NULL));
    int numrandom;
    for (int i = 0; i < dim; i++)
    {
        numrandom = (rand() % 20);
        v[i] = numrandom;
    }
}

void showvet(int v[], int dim, int start, int end)
{
    for (int i = start; i < end; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}


int dividivet(int v[], int dim, int *i, int *j, int num)
{
    int val = 0;
    *i = 0;
    *j = dim - 1;

    while (*i <= *j)
    {
        int mid = (*i + *j) / 2;
        if (v[mid] == num)
        {
            val = 1;
            *i = mid;
            *j = mid;
            break;
        }
        else if (v[mid] < num)
        {
            *i = mid + 1;
        }
        else
        {
            *j = mid - 1;
        }
    }

    return val;
}

void convalida(int match, int v[], int *i, int *j)
{
    if ((match == 1) or (match == 2) or (match == 20))
    {
        cout << "Il numero è stato trovato" << endl;
    }
    else if ((match == 0) or (match == 10))
    {
        cout << "Il numero non è presente" << endl;
    }
}

int main()
{
    srand(time(NULL));
    int numero = (rand() % 20);
    int dim = 10;
    cout << "Il numero da trovare è " << numero << endl;
    int vet[dim];
    randomizzavet(vet, dim);
    bubblesort(dim, vet);
    int i = 0;
    int j = dim - 1;
    int trovato = 0;
    trovato = dividivet(vet, dim, &i, &j, numero);
    convalida(trovato, vet, &i, &j);
    showvet(vet, dim, 0, dim);
    return 0;
}