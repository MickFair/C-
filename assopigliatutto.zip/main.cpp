/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#define MAZZO 40
#define CARTE_MANO 3
#define RICARICA_CARTE 3

#define CARTE_TERRA 4

using namespace std;


void shuffle(string vet[])
{  
   srand(time(NULL));
   int cont=0;
   string temp;
   while (cont<50)
   {
   string temp;
   int i=(rand()%40);
   int j=(rand()%40);
   temp=vet[i];
   vet[i]=vet[j];
   vet[j]=temp;
   cont=cont+1;
   }
}

void showvet(string vet[],int dim,string descr)
{  
      cout<<descr<<endl;
      for (int i=0;i<dim;i++)
      {
         if (vet[i]!=" ")
         {
         cout<<vet[i]<<" ";
         }
      }
      cout<<endl<<endl;
}
void distribuiscicarte(string mazzo[],int opt,string mazzocarte[],int *indicemazzo,bool *cardempty)
{
   
   if (*indicemazzo<MAZZO and *cardempty==false)
   {
      if (opt==1)
      {
         for (int i=0;i<CARTE_TERRA;i++)
         {
            mazzo[i]=mazzocarte[*indicemazzo];
            *indicemazzo=*indicemazzo+1;
         }
         for (int i=CARTE_TERRA;i<MAZZO;i++)
         {
            mazzo[i]=" ";
         }
         
      }
      else if(opt==2)
      {
            for (int i=0;i<CARTE_MANO;i++)
         {
            mazzo[i]=mazzocarte[*indicemazzo];
            *indicemazzo=*indicemazzo+1;
         }
      }
   }
   else
      {
      cout<<"Ultima Giocata"<<endl;
      *cardempty=true;
      }
}

   void mostracarte(string mazzo1[],string mazzo2[],string mazzo3[])
   {
   showvet(mazzo1,CARTE_MANO,"CPU");
   showvet(mazzo2,CARTE_TERRA,"TERRA");
   showvet(mazzo3,CARTE_MANO,"UTENTE");
   }

void mostramazzo(string mazzo[])
{
      for (int i=0;i<CARTE_MANO;i++)
      {
        if (mazzo[i]!=" ")
        {
            cout<<mazzo[i];
            if (i<CARTE_MANO-1)
                {
                    cout<<"--";
                }
        }
      }
      cout<<endl;
}   
string scelta(string mazzo[])
{  
      int input;
      cout<<"Che carta usi?"<<endl;
      mostramazzo(mazzo);
      switch (input)
      
      case 1
      break;
      case 2
      break;
      case 3
      break;
      default:
      cout<<"Scegli una carta valida "<<endl;
      break;
      
        return input;
}



int main()
{  
   bool cartefinite=false;
   int j=0;
   int estremodx=CARTE_TERRA;
   string cartascelta;
   //Creazione mazzi
   string vetmazzo[MAZZO]={"01D","02D","03D","04D","05D","06D","07D","08D","09D","10D","01C","02C","03C","04C","05C","06C","07C","08C","09C","10C","01S","02S","03S","04S","05S","06S","07S","08S","09S","10S","01B","02B","03B","04B","05B","06B","07B","08B","09B","10B"};
   string mazzocpu[CARTE_MANO];
   string mazzoutente[CARTE_MANO];
   string mazzoterra[MAZZO];
   //Riempimento Mazzo e Shuffle
   shuffle(vetmazzo);
   //Distribuzione Carte
   distribuiscicarte(mazzoterra,1,vetmazzo,&j,&cartefinite);
   distribuiscicarte(mazzocpu,2,vetmazzo,&j,&cartefinite);
   distribuiscicarte(mazzoutente,2,vetmazzo,&j,&cartefinite);
   mostracarte(mazzocpu,mazzoterra,mazzoutente);
   cartascelta=scelta(mazzoutente);
cout<<"prova"<<cartascelta;   

    return 0;
}




