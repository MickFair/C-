/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int n;
    int quadrato;
    int cubo;
    
    cout<<"Inserisci un numero";
    cin>>n;
    
    if ((n>0) or (n<0)){
        if (abs(n)%2==0){
            quadrato=n*n;
            cout<<quadrato;
        }
        else if (abs(n)%2==1){
            cubo=n*n*n;
            cout<<cubo;
            
        }
    }
    else if (n=0){
        cout<<"Il risultato è 0";
        
    }
    return 0;
}