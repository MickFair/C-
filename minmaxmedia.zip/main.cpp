/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
int numero=0;
char decisione='x';
bool uscita=false;
int cont=0;
int min;
int max;
float somma;

while (!uscita)
{
   cout<<"Inserisci un numero"<<endl;
   cin>>numero;
   if (cont==0)
   {
      min=numero;
      max=numero;
   }
   
   if (numero<min)
   {
      min=numero;
   }
   else if (numero>max)
   {
      max=numero;
   }
   cont++;
   cout<<"Hai finito?"<<endl;
   cin>>decisione;
      if (decisione=='s')
      {
         uscita=true;
      }
      somma=somma+numero;
}
cout<<"La media dei numeri è "<<somma/cont<<endl<<"Il massimo è "<<max<<endl<<"Il minimo è "<<min<<endl<<"Hai inserito "<<cont<<" numeri"<<endl;

    return 0;
}
