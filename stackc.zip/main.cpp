/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int check(int *temp) //Controllo su input del menu
{
    cin>>*temp;
    while ((cin.fail()))
    {
        cin.clear();
        cin.ignore();
        cout<<"Invalid input"<<endl;
        cin>>*temp;
    }
    return *temp;
}

void put(int array[], int *head, int num, bool *full, bool *empty){

    if (*full==false) //se full è falso,si memorizza
    {
        cout<<"Che elemento numerico vuoi aggiungere?"<<endl;
        num=check(&num); //richiama funzione check (DAJEEE)
        *head=*head + 1; //head incrementa per l'eventuale prossimo input
        array[*head]=num;
        *empty=false; //lo stack non è più vuoto
        cout<<"Put avvenuto con successo"<<endl;
        if (*head==5) //se head==dim vettore,è pieno
            *full=true;
        else
        {
            *full=false;
        }
    }
    else if (*full==true) //se full è true lo stack è pieno e non si memorizza
        cout<<"Lo stack è pieno!"<<endl;
    
        
}

void pop(int array[], int *head,bool *empty,bool *full)
{   
    if (*empty==false) //Se empty è falso,si fa il pop
    {
        *head=*head - 1; //head decrementa
        *full=false; //non è più pieno il vettore
        cout<<"Pop avvenuto con successo"<<endl;
        if (*head==-1) //se head scende sotto la grandezza del vettore,è vuoto
            *empty=true;
        else
            *empty=false;
    }
    else
    {
        cout<<"Lo stack è vuoto!"<<endl;
        *empty=true;
    }
}

void top(int array[], int head,bool *empty)
{
    int top=head;
    if (*empty==true) //se è vuoto,non c'è nulla
        cout<<"Lo stack è vuoto!"<<endl;
    else
        cout<<array[head]<<" è l'elemento top"<<endl; //altrimenti si espone il valore in testa
}

void isfull (int array[],bool *full)
{   
     if (*full==false) //se full è falso,non è pieno
    {
        cout<<"Lo stack non è pieno"<<endl;
    }
    else
    {
        cout<<"Lo stack è pieno"<<endl;
    }
            
}

void isempty (int array[],bool *empty)
{
     if (*empty==true) //se empty è true,stack vuoto
    {
        cout<<"Lo stack è vuoto"<<endl;
    }
    else
    {
        cout<<"Lo stack non è vuoto"<<endl;
    }
    
}

void clear (int array[],int *head,bool *empty,bool *full)
{
            if (*empty==false) //se empty è falso,avviene il clear
            { 
                *head=-1;
                *empty=true; //empty ora è true
                *full=false; //full è falso
                cout<<"Lo stack è stato svuotato"<<endl;
            }
            else //altrimenti,se è 0 la pos più bassa,lo stack è già vuoto
            cout<<"Lo stack è già vuoto!"<<endl;
            
}

void showstack (int array[],bool empty,int testa)
{
    if (empty==false) //se empty è falso,si mostra il vettore
    {
        for (int i=testa;i>=0;i--) //visualizzazione stack
        {
            cout<<array[i]<<" ";
        }
    }
    else
        cout<<"Lo stack è vuoto!"<<endl;
        
        cout<<endl;
}
int main()
{
    bool close=false; //var bool per uscita programma
    int array[5];
    int input;
    int num;
    int i;
    int head=-1; //var per tenere traccia della posizione degli input immessi
    bool stackempty=true;
    bool stackfull=false;

    cout<<"Benvenuto nel menu"<<endl;
  
  
    
    while (close==false)
    {
        cout<<"Cosa vuoi fare?"<<endl<<"1=Put"<<endl<<"2=Pop"<<endl<<"3=TopElem"<<endl<<"4=StackFull"<<endl<<"5=StackEmpty"<<endl<<"6=Clear"<<endl<<"7=Visualizza Stack"<<endl<<"8=Esci dal programma"<<endl;
        input=check(&input);
        
        switch (input)
        {
        case 1:
        put(array, &head, num,&stackfull,&stackempty);
        break;
        case 2:
        pop(array,&head,&stackempty,&stackfull);
        break;
        case 3:
        top(array,head,&stackempty);
        break;
        case 4:
        isfull(array,&stackfull);
        break;
        case 5:
        isempty(array,&stackempty);
        break;
        case 6:
        clear (array,&head,&stackempty,&stackfull);
        break;
        case 7:
        showstack(array,stackempty,head);
        break;
        case 8:
            close=true;
        break;
        default:
            cout<<"Invalid input"<<endl;
        break;
        }
    }
    cout<<"Sei uscito dal programma";

    return 0;
}







