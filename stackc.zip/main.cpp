/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void check(int *temp) //Controllo su valore numerico del put
{
    cin>>*temp;
    while ((cin.fail()) or (*temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>*temp;
        
    }
}


void checkinp(int *temp) //Controllo su input del menu
{
    cin>>*temp;
    while ((cin.fail()) or (*temp<1) or (*temp>8))
    {
        cin.clear();
        cin.ignore();
        cout<<"Invalid input"<<endl;
        cin>>*temp;
        
    }
}

void put(int array[], int *head, int num){
    
    if (array[5]==0) //se (array) alla pos più alta è 0,lo stack ha ancora spazio per memorizzare
    {
        cout<<"Che elemento numerico vuoi aggiungere?"<<endl;
        cin>>num;
        array[*head]=num;
        *head=*head + 1; //head incrementa per l'eventuale prossimo input
    }
    else //se array alla 5a posizione(la più alta) ha un valore diverso da 0,è pieno
        cout<<"Lo stack è pieno!"<<endl;
        
        cout<<"Put avvenuto con successo"<<endl;
}

void pop(int array[], int *head)
{
    *head=*head - 1; //head torna indietro di una posizione,poichè si trova in una cella dove il valore è 0
    if (array[0]==0) //se (array) alla pos più bassa è 0,lo stack è vuoto
        cout<<"Lo stack è vuoto!"<<endl<<"Pop non avvenuto"<<endl;
    else
    {
        array[*head]=0; //altrimenti array[head] si azzera
        cout<<"Pop avvenuto con successo"<<endl;
    }
}

void top(int array[], int *head)
{
    if (array[0]==0) //se (array) alla pos più bassa è 0,lo stack è vuoto
        cout<<"Lo stack è vuoto!"<<endl;
    else
        cout<<array[*head-1]<<" è l'elemento top"<<endl; //array con head -1 mostra l'elemento top,poichè col "put",head va a +1 dove array[head] vale 0
        }

void isfull (int array[])
{
     if (array[5]==0) //se array al top è 0,non è pieno
            cout<<"Lo stack non è pieno"<<endl;
            else
            cout<<"Lo stack è pieno"<<endl;
}

void isempty (int array[])
{
     if (array[0]==0) //se array alla pos più bassa è 0,è vuoto
            cout<<"Lo stack è vuoto"<<endl;
            else
            cout<<"Lo stack non è vuoto"<<endl;
}

void clear (int array[],int *head)
{
            if (array[0]!=0) //se array alla pos più bassa è diverso da 0,il clear avviene
            { 
                for (int i=*head;i>=0;i--) //i parte dal valore di head
                {
                    array[i]=0;
                }
                cout<<"Lo stack è stato svuotato"<<endl;
            }
            else //altrimenti,se è 0 la pos più bassa,lo stack è già vuoto
            cout<<"Lo stack è già vuoto!"<<endl;
}

void showstack (int array[])
{
     int i=5;
        while (i>=0) //visualizzazione stack
        {
            if (array[i]==0) //separazione dei valori di ogni cella con lo spazio
            cout<<" ";
            else
            cout<<array[i]<<" ";
            
            i--;
        }
        cout<<endl;
}
int main()
{
    bool close=false; //var bool per uscita programma
    int array[5];
    int input;
    int num;
    int i;
    int head=0; //var per tenere traccia della posizione degli input immessi

    cout<<"Benvenuto nel menu"<<endl;
  
  
    
    while (close==false)
    {
        cout<<"Cosa vuoi fare?"<<endl<<"1=Put"<<endl<<"2=Pop"<<endl<<"3=TopElem"<<endl<<"4=StackFull"<<endl<<"5=StackEmpty"<<endl<<"6=Clear"<<endl<<"7=Visualizza Stack"<<endl<<"8=Esci dal programma"<<endl;
        checkinp(&input);
        
        switch (input)
        {
        case 1:
        put(array, &head, num);
        break;
        case 2:
        pop(array,&head);
        break;
        case 3:
        top(array,&head);
        break;
        case 4:
        isfull(array);
        break;
        case 5:
        isempty(array);
        break;
        case 6:
        clear (array,&head);
        break;
        case 7:
        showstack(array);
        break;
        case 8:
            close=true;
        break;
        default:
            close=true;
        break;
        }
    }
    cout<<"Sei uscito dal programma";

    return 0;
}





