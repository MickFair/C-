/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void check(int *temp) //Controllo su input
{
    cin>>*temp;
    while ((cin.fail()) or (*temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>*temp;
        
    }
}

int main()
{
    bool close=false; //var bool per uscita programma
    int array[5];
    int input;
    int num;
    int i;
    int point=0; //var per tenere traccia della posizione degli input immessi

    cout<<"Benvenuto nel menu"<<endl;
  
  
    
    while (close==false)
    {
        cout<<"Cosa vuoi fare?"<<endl<<"1=Put"<<endl<<"2=Pop"<<endl<<"3=TopElem"<<endl<<"4=StackFull"<<endl<<"5=StackEmpty"<<endl<<"6=Clear"<<endl<<"7=Visualizza Stack"<<endl<<"8=Esci dal programma"<<endl;
        cin>>input;
        
        switch (input)
        {
        case 1:
                i=5;
                if (array[i]==0) //se (array) alla pos più alta è 0,lo stack ha ancora spazio per memorizzare
                {
                cout<<"Che elemento numerico vuoi aggiungere?"<<endl;
                check(&num); //controlla input
                while ((array[i]==0) and (i>point)) //Finchè l'array ha il valore 0 e la i è superiore alla posizione(point) dell'ultimo valore immesso
                {
                    i--;
                }
                array[i]=num;
                point++; //point incrementa per l'eventuale prossimo input
                }
                else //altrimenti è pieno
                cout<<"Lo stack è pieno!"<<endl;
        break;
        case 2:
                if (array[0]!=0) //se l'array alla pos 0 è diverso da 0,possiamo cancellare perchè l'array non è vuoto
                {
                    
                i=5;
                cout<<"Che elemento numerico vuoi cancellare?"<<endl;
                check(&num);
                while (array[i]!=num) //la i decrementa finchè non trova un valore adiacente,cancellando ogni valore si presenti in ogni cella
                {
                    array[i]=0;
                    i--;
                }
                array[i]=0;
                point=i;
                }
                else
                cout<<"Lo stack è vuoto!"<<endl;
        break;
        case 3:
            i=5;
            while ((array[i]==0) and (i>=0)) //controllo del valore in array e che la i non vada out of range
            {
                i--;
            }
            if (array[i]!=0) //controllo che,anche se la i arrivi a 0,il valore non sia 0,altrimenti non c'è un numero top
            {
            cout<<"Il numero "<<array[i]<<" è l'elemento Top"<<endl;
            }
            else
            cout<<"Non esiste un numero top"<<endl;
        break;
        case 4:
            i=5;
            if (array[i]==0) //se array al top è 0,non è pieno
            cout<<"Lo stack non è pieno"<<endl;
            else
            cout<<"Lo stack è pieno"<<endl;
        break;
        case 5:
            i=0;
            if (array[i]==0) //se array alla pos 0 è 0,è vuoto
            cout<<"Lo stack è vuoto"<<endl;
            else
            cout<<"Lo stack non è vuoto"<<endl;
        break;
        case 6:
            i=5; //funzione clear di ogni valore fino allo 0
            while (i>=0)
            {
            array[i]=0;
            i--;
            }
            cout<<"Lo stack è stato svuotato"<<endl;
        break;
        case 7:
        i=5;
        while (i>=0) //visualizzazione stack
        {
            if (array[i]==0)
            cout<<" ";
            else
            cout<<array[i]<<" ";
            
            i--;
        }
        cout<<endl;
        break;
        case 8:
            close=true;
        break;
        default:
            close=true;
        break;
        }
    }
    cout<<"Sei uscito dal programma";

    return 0;
}
