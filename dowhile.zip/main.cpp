/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int numero=0;
    int verifica=0;
    int max=0;
    int cont=0;
    
    do
    {
        verifica=numero;
        cout<<"Inserisci il numero"<<endl;
        cin>>numero;
        max=max+numero;
        cont=cont+1;
    }
    
    while (numero>=verifica);
    verifica=numero;
    if (cont>1)
    {
    cout<<"La somma dei numeri è "<<max-numero<<endl;
    cout<<"Sono stati inseriti "<<cont<<" numeri";
    }
    else if (cont<=1)
    {
        cout<<"È stato inserito "<<cont<<" numero,il "<<max-numero;
    }
    return 0;
}

