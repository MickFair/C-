/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int x=20;
    int vet[x]; //Vettore
    int dopp[x]; //Doppioni
    int ran=3; //Range random
    int temp=0; //Numero temporaneo da controllo
    int doppione=0; //Contatore doppioni
    

        srand(time(NULL)); // Seme funzione rand() vettore p[i]
    
    for (int i=0;i<x;i++)
    {
       vet[i]=(rand()%ran+1); //Numeri random fino a X,variabili
    }
       
       cout<<"Stampa Vettore"<<endl;
       
           for (int i=0;i<x;i++)
    {
        cout<<"Pos "<<i<<" Numero "<<vet[i]<<endl;
    }
    
    for (int j=0;j<x;j++)
    {
        temp=vet[j];
                    for (int i=j;i<x;i++)
                        {
                        if (vet[i]==temp)
                            {
                            doppione=doppione+1;
                            dopp[j]=doppione;
                            }
                        
                        }
    doppione=0;
    }
    
    int max=0;
    int posmax=0;
    
    for (int i=0;i<x;i++)
    {
        if (dopp[i]>max)
        {
        max=dopp[i];
        posmax=i;
        }
    }
    
    cout<<"Il numero "<<vet[posmax]<<" ha "<<max-1<<" doppioni";
    
    
      
    return 0;
}