/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void scambia (int vet[],int dim)
{
int temp=0;

for (int i=0;i<dim;i=i+2)
{
    temp=vet[i];
    vet[i]=vet[i+1];
    vet[i+1]=temp;
}
 
}

int main()
{
    int v[12]{2,1,4,3,6,5,8,7,10,9,12,11};
    
    for (int j=0;j<12;j++)
    {
        cout<<v[j]<<" ";

    }
    cout<<" "<<endl;
    cout<<"Passo"<<endl;
scambia (v,12);
 
    
     for (int j=0;j<12;j++)
    {
        cout<<v[j]<<" ";

    }
    return 0;
}
