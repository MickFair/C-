/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void stampavettore(int v[],int dim)
{
   for (int i=0;i<dim;i++)
   {
      cout<<v[i]<<" ";
   }
   cout<<endl;
}

int main()
{
   
int r=10;
int dim1=10;
int vetorig[dim1];
int vetdopp[dim1];
int varcontrollo=0;
bool uscita=false;

   srand(time(NULL));
   
    for (int i=0;i<dim1;i++)
    {
       vetorig[i]=(rand()%r+1); //Numeri random fino a X,variabili
       
    }

for (int i=0;i<dim1;i++)
{
   vetdopp[i]=0;
}

 
   for (int j=0;j<dim1;j++)
   {
      for (int i=0;i<dim1;i++)
      {
         if (vetorig[i]==vetorig[j])
         {
            vetdopp[j]=vetdopp[j]+1;
         }
      }
   }

stampavettore(vetorig,dim1);

cout<<"I numeri apparsi una volta sono : ";
for (int i=0;i<dim1;i++)
{
   if (vetdopp[i]==1)
   {
      cout<<vetorig[i]<<" ";
   }
}

    return 0;
}