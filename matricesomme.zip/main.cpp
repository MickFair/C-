/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;



void stampavettore(int v[],int dim, string descr) //Funzione stampa 
{
    cout<<"Vettore " + descr <<endl;
    for (int i=0;i<dim;i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<""<<endl;
}

int somma(int v[],int dim,int pos) //Funzione somma dei valori del vettore data una [pos],con incremento a due
{
    int sommavet=0;
    for (int i=pos;i<dim;i=i+2)
    {
     sommavet=sommavet+v[i];
    }
    
    return sommavet;
}

int main()
{
    int n=10; //Dimensione vettori
    int v1[n]; //Vett1
    int v2[n]; //Vett2
    int v3[n]; //Vett3
    int vetsomme[n]; //Vettore con somme di [i]esima posizione di ciasciun vettore
    int ran=50; //Range numeri random
    int x=4; //Righe Matrice
    int y=2; //Colonne Matrice
    int matricesomme[x][y];
    
    srand(time(NULL)); // Seme funzione rand() vettore v[i]
    
    for (int i=0;i<10;i++)
    {
       v1[i]=(rand()%ran+1); //Numeri random fino a X,variabili
       v2[i]=(rand()%ran+1);
       v3[i]=(rand()%ran+1);
    }
    
    for (int i=0;i<n;i++) //Somma dei numeri in [i]esima posizione in vetsomme
    {
        vetsomme[i]=v1[i]+v2[i]+v3[i];
    }
    
    
       
    stampavettore(v1,n,"1"); //Funzione stampa
    stampavettore(v2,n,"2");
    stampavettore(v3,n,"3");
    stampavettore(vetsomme,n,"somme");

    for (int i=0;i<n;i++) 
    {
        if (i%2==0) 
        {
            matricesomme[0][0]=matricesomme[0][0]+v1[i];
            matricesomme[1][0]=matricesomme[1][0]+v2[i];
            matricesomme[2][0]=matricesomme[2][0]+v3[i];
            matricesomme[3][0]=matricesomme[3][0]+vetsomme[i];

        }
        if (i%2==1) 
        {
            matricesomme[0][1]=matricesomme[0][1]+v1[i];
            matricesomme[1][1]=matricesomme[1][1]+v2[i];
            matricesomme[2][1]=matricesomme[2][1]+v3[i];
            matricesomme[3][1]=matricesomme[3][1]+vetsomme[i];
        }
                
    }
cout<<"Matrice"<<endl;

        for (int i=0;i<x;i++)
    {
            for (int j=0;j<y;j++)
                {
                cout<<matricesomme[i][j]<<endl;
                }
    }
    
    
    return 0;
}



