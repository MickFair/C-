/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void scambia (int v[],int dim,int pos)
{
    int a=dim-1;
    
    for (a;a>pos;a--)
    {
        v[a]=v[a-1];
    }
    
}
int main()
{
    int v[4]{4,5,3,2};
    int j=1;
    scambia (v,4,j);
    v[j]=1;
     while (j<4)
    {
        cout<<v[j];
        j++;
    }
    
    

    return 0;
}
