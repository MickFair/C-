/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int vetmax(int v[],int dim)
{    
    int max=0;
    for (int i=0;i<dim;i++)
    {
        if (v[i]>max)
        {max=v[i];}
        
    }
    
    return max;
}

int vetmax2(int v[],int dim,int a)
{    
    int max2=0;
    for (int i=0;i<dim;i++)
    {
        if ((v[i]<a) and (v[i]>max2))
        {max2=v[i];}
        
    }
    
    return max2;
}

int main()
{
    int n=20;
    int ran=30;
    int vet[n];
    
    srand(time(NULL)); // Seme funzione rand() vettore p[i]
    
    for (int i=0;i<n;i++)
    {
       vet[i]=(rand()%ran+1); //Numeri random fino a X,variabili
        
        for(int j=0;j<i;j++) 
        {
       	    if(vet[i]==vet[j]) 
       	    {
            i--;
            }
        }
       
       
    }
    
    cout<<"Elenco dei numeri: "<<endl;
      
    for (int i=0;i<n;i++)
    {
        cout<<vet[i]<<" ";
    }
    int max=0;
    int max2=0;
         max=vetmax(vet,n);
         max2=vetmax2(vet,n,max);
         
         cout<<""<<endl;
         cout<<"I due massimi sono "<<max<<" e "<<max2;
   
    
    return 0;
}