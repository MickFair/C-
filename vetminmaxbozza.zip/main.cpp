/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <ctime>
using namespace std;

int vetlow(int v[],int dim)
{    
    
    int low=0;
    for (int i=0;i<dim;i++)
    {
        if (i==0)
        {
            low=v[i];
        }
        
        if (v[i]<low) 
        {low=v[i];}
        
    }
    
    return low;
}

int vethigh(int v[],int dim)
{    
    int high=0;
    for (int i=0;i<dim;i++)
    {
        if (v[i]>high)
        {high=v[i];}
        
    }
    
    return high;
}

int main ()
{
    int n=20;
    int p[n];
    int max;
    int min;
    int vmaxmin[3];
    
for (int i=0;i<n;i++)
    {
       p[i]=(rand()%100+1); //Numeri random fino a X,variabili
       
       for(int j=0;j<i;j++) 
       {
       	if(p[i]==p[j]) 
       	{
           i--;
        }
       }
       
    }

for (int i=0;i<n;i++)
{
    cout<<p[i]<<" ";
}


max=vethigh(p,n);
vmaxmin[0]=max;
min=vetlow(p,n);
vmaxmin[1]=min;

        cout<<"Il numero massimo è "<<vmaxmin[0]<<" ed il minimo è "<<vmaxmin[1]<<endl;

int temp=0;

    temp=vmaxmin[0];
    vmaxmin[0]=vmaxmin[1];
    vmaxmin[1]=temp;
    
                cout<<"Scambio max a min "<<vmaxmin[0]<<" scambio min a max "<<vmaxmin[1]<<endl;

for (int i=0;i<n;i++)
{
    if ((p[i]<max) and (p[i]>min) and (p[i]>vmaxmin[2]))
    {
        vmaxmin[2]=p[i];
    }
}
    cout<<"In mezzo prima sta "<<vmaxmin[1]<<endl;

    temp=vmaxmin[1];
    vmaxmin[1]=vmaxmin[2];
    vmaxmin[2]=temp;
    
cout<<"Poi scambiando sta "<<vmaxmin[1];
    


return 0;
}