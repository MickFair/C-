/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void stampavettore(int v[],int dim, string descr) //Funzione stampa 
{
    cout<<"Vettore " + descr <<endl;
    for (int i=0;i<dim;i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<""<<endl;
}

int somma(int v[],int dim,int pos) //Funzione somma dei valori del vettore data una [pos],con incremento a due
{
    int sommavet=0;
    for (int i=pos;i<dim;i=i+2)
    {
     sommavet=sommavet+v[i];
    }
    
    return sommavet;
}

int vetmax(int v[],int dim) //Trova il numero max in un vet
{    
    int max=0;
    for (int i=0;i<dim;i++)
    {
        if (v[i]>max)
        {max=v[i];}
        
    }
    
    return max;
}

    srand(time(NULL)); // Seme funzione rand() vettore p[i]
    
    for (int i=0;i<n;i++)
    {
       p[i]=(rand()%ran+1); //Numeri random fino a X,variabili
       
       for(int j=0;j<i;j++) 
       {
       	if(p[i]==p[j]) 
       	{
           i--;
        }
       }
       
    }
    
void scambia (int vet[],int dim) //Funzione scambia per bubble sort
{
int temp=0;

for (int i=0;i<dim;i=i+2)
{
    temp=vet[i];
    vet[i]=vet[i+1];
    vet[i+1]=temp;
}
 
}

void scambia (int v[],int dim,int pos) //Shift a dx di vettore
{
    int a=dim-1;
    
    for (a;a>pos;a--)
    {
        v[a]=v[a-1];
    }
    
}

int check() //Controllo su input
{
    int temp;
    cin>>temp;
    while ((cin.fail()) or (temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>temp;
        
    }
    return temp;
}


int main()
{
    cout<<"Hello World";

    return 0;
}