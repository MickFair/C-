/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void stampavettore(int v[],int dim,string descr) //Funzione stampa 
{
    cout<<"Vettore "+ descr<<endl;
    for (int i=0;i<dim;i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<""<<endl;
}

int main()
{
    /*Randomizza il vettore V2 fino a quando non corrisponde al V1*/
    int n=5; //cardinalità del vettore
    int v1[n]={5,3,3,6,7};
    int v2[n]={7,4,2,9,5};
    int v3[n];
    int ran=10;
    bool match=false;
    int i=0;
    int j=0;
    int cont=0;

    
    srand(time(NULL)); // Seme funzione rand() vettori
    
    for (int i=0;i<n;i++) //si inizializza il vettore v3 a zero
    {
       v3[i]=0;
    }
    
    while(!match) // Si esegue il ciclo while fino a quando non è trovato un vettore v2 == a v1
    {       
        for (j=0;j<n;j++)
        {
            if (v1[i]==v2[j] and v3[j]==0)
            {
                v3[j]=v1[i];
                i++;
            }
            else 
                i++;
        }
        j=0;

        while (j<n)
        {
            if (v3[j]==0)
            {   
                match=false;
                j=n;
            }
            
            else
                {match=true;}
            j++;
        }
        
        if (match==false)
        {
            for (int i=0;i<n;i++)
            {      
                v2[i]=(rand()%ran+1);
                v3[i]=0;
            }
            cont=cont+1;
            i=0;
        }
        
}
        

cout<<"I vettori sono uguali e sono stati resettati casualmente "<<cont<<" volte"<<endl;
stampavettore(v1,n,"1"); //Funzione stampa 
stampavettore(v2,n,"2"); //Funzione stampa 


    
    return 0;
}


