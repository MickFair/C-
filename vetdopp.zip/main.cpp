/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    n=10;
    int vet[n];
    int doppioni=0;
    int temp=0;
    int vetdopp[n];
    
    for (int )
    cin>>
    
for (int i=0;i<n;i++)
    {
    for (int i=0;i<n;i++)
        {
            temp=vet[i];
            if (vet[i]==temp)
            {
                doppioni=doppioni+1;
            }
            
        }
        vetdopp[i]=doppioni;
    }
    return 0;
}