/******************************************************************************

In un vettore di n elementi,il primo  ad essere inserito rappresenta sia la testa che la coda di esso,dal secondo in poi,anzichè spostare la testa
a destra e,di conseguenza,shiftare di 1 posizione ogni elemento,andiamo a memorizzare spostando la coda verso sinistra,memorizzando
gli elementi ad ogni inserimento,evitando così di eseguire shift.
Per l'estrazione,si azzera il valore contenuto nella cella a cui punta la testa e poi si sposta la testa ad una cella precedente.
Per la visualizzazione,si usa un indice che parte dalla coda ed arriva alla testa in base a quanti elementi (var. empty) siano stati inseriti.

È più logico pensare ad una coda di stampa simile

10 9 8 7 6 5 4 3 2 1

Dove 1 è il primo elemento inserito,ed effettuando un'estrazione,il vettore risulta

10 9 8 7 6 5 4 3 2 

Inserendo un elemento,come per esempio l'1,il risultato è il seguente

1 10 9 8 7 6 5 4 3 2

*******************************************************************************/
#include <iostream>

using namespace std;

int check() //Controllo su input
{
    int temp;
    cin>>temp;
    while (cin.fail()) 
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>temp;
        
    }
    return temp;
}

void inqueue (int vet[], int dim, int *coda, int *cont, int num) //Funzione di inqueue
{  

    if (*coda==0) //Se la coda==0,parte dalla "fine" del vettore
    {
        if (*cont>0)
        {
        *coda=dim-1;
        }
    }
    else
    {
        if (*cont>0)
        {
        *coda=*coda-1;
        }
    }
    
    vet[*coda]=num; //Coda=numero input
    *cont=*cont+1;

    cout<<"Numero inserito"<<endl;
}

void dequeue (int vet[],int dim,int *testa,int *cont) //Funzione dequeue
{   

    if (*testa==0) //Se la testa==0,la testa parte dalla fine del vettore
    {
        *testa=dim-1;
    }
    else
    {
        *testa=*testa-1;
    }
    vet[*testa]=0;
    *cont=*cont-1;

    cout<<"Dequeue avvenuto con successo"<<endl;
}

void showvet (int vet[], int dim, int coda, int cont) //Funzione mostra vettore
{   
    int i=coda; // la i parte dalla coda
    
    cout<<"---->"<<" "; 
    while (cont > 0)
    {
        if (i == dim-1) //Se la i è uguale alla dim del vettore-1,la i parte dall'inizio del vettore
        {
            cout<<vet[i]<<" ";
            i = 0;

        }
        else
        {
            cout<<vet[i]<<" ";
            i = i + 1;

        }
        cont = cont-1;

    }
    cout<<"---->"<<" "; 
    cout<<endl;
}

void visualizzamenu() //Visualizza il menu
{
    cout<<"Cosa vuoi fare?"<<endl;
    cout<<"1 = Incoda"<<endl;
    cout<<"2 = Estrai"<<endl;
    cout<<"3 = Visualizza"<<endl;
    cout<<"4 = Esci"<<endl;
    cout<<"5 = Visualizza Coda"<<endl;
    cout<<"6 = Visualizza Testa"<<endl;


}

int main()
{   
    int n;
    cout<<"Grandezza vettore?"<<endl;
    n = check();
    int head, tail, empty = 0;
    int vettore[n];
    int input,num;
    bool esci=false;
    
    while (esci==false)
    {
        visualizzamenu();

        cin>>input;
        switch (input) //Switch case dei vari input
        {
            case 1:
                if (empty<n)
                    {
                    cout<<"Che numero vuoi inserire?"<<endl;
                    num=check();
                    inqueue(vettore, n, &tail, &empty, num);
                    }
                else 
                    cout<<"La coda è piena!"<<endl;
            break;
            case 2:
                if (empty>0)
                    {
                    dequeue(vettore,n,&head,&empty);
                    }
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
            case 3:
                if (empty > 0)
                    showvet(vettore, n, tail, empty);
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
            case 4:
                esci=true;
            break;
               case 5:
               if (empty>0)
                cout<<"Coda = "<<vettore[tail]<<endl;
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
             case 6:
                if (empty>0)
                cout<<"Testa = "<<vettore[head]<<endl;
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
            default:
                 cout<<"Scelta errata"<<endl<<endl<<endl<<endl;
            break;
        }
}

cout<<"Sei uscito dal programma";
    return 0;
}


