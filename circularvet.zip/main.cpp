/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int check() //Controllo su input
{
    int temp;
    cin>>temp;
    while ((cin.fail()) or (temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>temp;
        
    }
    return temp;
}

void inqueue (int vet[],int dim,int *coda,int *cont,int num) //Funzione di inqueue
{  
    vet[*coda]=num; //Coda=numero input
    
        if (*coda==0) //Se la coda==0,parte dalla "fine" del vettore
        {
            *coda=dim-1;
        }
        else
        {
        *coda=*coda-1;
        }
        
        *cont=*cont+1;

    cout<<"Numero inserito"<<endl;
}

void dequeue (int vet[],int dim,int *testa,int *cont) //Funzione dequeue
{   
    vet[*testa]=0;
    
    if (*testa==0) //Se la testa==0,la testa parte dalla fine del vettore
    {
        *testa=dim-1;
    }
    else
    {
        *testa=*testa-1;
    }
    
    *cont=*cont-1;

    cout<<"Dequeue avvenuto con successo"<<endl;
}

void showvet (int vet[],int dim,int *coda,int cont) //Funzione mostra vettore
{   
    int i;
    if (*coda==dim-1) //Se la coda è al margine destro vettore,la i parte dall'inizio poichè la cella *coda è vuota
    {
        i=0;
    }
    else
     i=*coda+1; //Altrimenti la i parte dalla pos. coda+1
     
    while (cont>0)
    {
            cout<<vet[i]<<" ";
        if (i>=dim-1) //Se la i arriva a fine vettore e cont è ancora superiore a 0,la i parte dall'inizio del vettore
        {
            i=0;

        }
        else
        {
            i=i+1;

        }
        cont=cont-1;

    }
    cout<<endl;
}

void visualizzamenu()
{
    cout<<"Cosa vuoi fare?"<<endl;
    cout<<"1=Incoda"<<endl;
    cout<<"2=Estrai"<<endl;
    cout<<"3=Visualizza"<<endl;
    cout<<"4=Esci"<<endl;
}

int main()
{   
    int n;
    cout<<"Grandezza vettore?"<<endl;
    n=check();
    int head,tail,empty=0;
    int vettore[n];
    int input,num;
    bool esci=false;
    
       while (esci==false)
{
    visualizzamenu();

    cin>>input;
        switch (input) //Switch case dei vari input
        {
            case 1:
                if (empty<n)
                    {
                    cout<<"Che numero vuoi inserire?"<<endl;
                    num=check();
                    inqueue(vettore,n,&tail,&empty,num);
                    }
                else 
                    cout<<"La coda è piena!"<<endl;
            break;
            case 2:
                if (empty>0)
                    {
                    dequeue(vettore,n,&head,&empty);
                    }
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
            case 3:
                if (empty>0)
                    showvet(vettore,n,&tail,empty);
                else
                    cout<<"La coda è vuota!"<<endl;
            break;
            case 4:
                esci=true;
            break;
            default:
                esci=true;
            break;
        }
}

cout<<"Sei uscito dal programma";
    return 0;
}

