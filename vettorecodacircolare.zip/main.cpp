/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


void showvet (int vet[], int dim, int coda, int cont,int codavuota) //Funzione mostra vettore
{   
    if (codavuota==false) //Controllo coda non sia vuota
    {
    cout<<"Coda -->"<<" "; 
        while (cont > 0)
        {
            if (coda == dim-1) //Se la coda parte dalla fine del vettore,visualizza e parte dall'inizio
            {
                cout<<" "<<vet[coda]<<"|";
                coda = 0;
    
            }
            else
            {
                cout<<" "<<vet[coda]<<"|"; //Altrimenti incrementa
                coda = coda + 1;
    
            }
            cont = cont-1;
    
        }
    cout<<"<- Testa ---->"<<" "; 
    cout<<endl;
    }
    else
        cout<<"Il buffer è vuoto"<<endl;
}

void visualizzamenu() //Visualizza il menu
{
    cout<<"Cosa vuoi fare?"<<endl;
    cout<<"1 = Incoda"<<endl;
    cout<<"2 = Estrai"<<endl;
    cout<<"3 = Visualizza Buffer"<<endl;
    cout<<"4 = Esci"<<endl;
    cout<<"5 = Visualizza Coda"<<endl;
    cout<<"6 = Visualizza Testa"<<endl;
    cout<<"7 = Buffer Vuoto"<<endl;
    cout<<"8 = Buffer Pieno"<<endl;
    cout<<"9 = Svuota Buffer"<<endl;


}

void check(int *temp) //Controllo su input
{
    cin>>*temp;
    while (cin.fail()) 
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>*temp;
        
    }
}

void inqueue (int vet[], int dim, int *coda, int *testa, int *cont,int input,bool *codapiena,bool *codavuota) //Funzione di inqueue
{  
    if (*codapiena==false)
    {
        cout<<"Che numero vuoi inserire?"<<endl;
        check(&input);
                        
        if (*coda==-1) //Se la coda è fuori dal vettore,testa e coda partono dalla posizione 0
        {
            *coda=*coda+1;
            *testa=*coda;
            vet[*coda]=input;
        }
        
        else if(*coda==0) //se la coda è alla posizione 0,la coda parte dalla fine del vettore
        {
            *coda=dim-1;
            vet[*coda]=input;

        }
        else if (*coda>0) //se la coda è in pos>0,decrementa normalmente
        {
            *coda=*coda-1;
            vet[*coda]=input;
        }
        *cont=*cont+1;
        *codavuota=false;

        if (*cont==dim) //se contatore è DIM e non DIM-1(perchè quando con è 0 la coda è vuota),la coda è piena
        {
            *codapiena=true;
        }
        cout<<"Inqueue del numero "<<input<<" avvenuto con successo"<<endl;
        showvet(vet, dim, *coda, *cont,*codavuota); //mostra vettore dopo inqueue
    }
    else
        cout<<"Il buffer è pieno"<<endl;
}

void dequeue (int vet[],int dim,int *testa,int *coda, int *cont,bool *codavuota,bool *codapiena) //Funzione dequeue
{   
    if (*codavuota==false)
    {
        int temp=vet[*testa]; //variabile temporanea per mostrare a schermo il valore estratto
        if (*testa==0) //Se la testa==0,la testa parte dalla fine del vettore
        {
            *testa=dim-1;
            *cont=*cont-1;
        }
        else if (*testa>0) //se la testa è in pos >0,decrementa normalmente
        {
            *testa=*testa-1;
            *cont=*cont-1;
        }
        else if (*testa==*coda) //se testa e coda sono nella stessa posizione..
        {
            if (*testa==0) //se la testa è in posizione 0,parte dalla fine del vettore
            {
            *testa=dim-1;
            }
            else
            {
            *testa=*testa-1; //altrimenti decrementa
            }
            
            *coda=*testa; //in entrambi i casi,testa e coda si appoggiano successivamente sulla stessa cella
        }
       cout<<"Dequeue del numero "<<temp<<" avvenuto con successo"<<endl; //variabile temporanea creata precedentemente
        *codapiena=false;
        
        if (*cont==0) //se contatore è 0,la coda è vuota
        *codavuota=true;
        
        if (*codavuota==false)
        {
        showvet(vet, dim, *coda, *cont,*codavuota);
        }
    }
    else
        cout<<"Il buffer è vuoto"<<endl;

}

void mostravet(int vet[],int point,string descr,int codavuota) //funzione mostra vettore,self explaining
{   
    if (codavuota==false) 
    {
    cout<<"Nella "<<descr<<" del buffer c'è il numero "<<vet[point]<<endl;
    }
    else
    cout<<"La "<<descr<<" del buffer è vuota"<<endl;
}
void bufferstatus(bool status,string descr) //funzione status vettore,di nuovo,self explaining
{
    if (status==true)
    cout<<"Il buffer è "<<descr;
    else
    cout<<"Il buffer non è "<<descr;
    
    cout<<endl;
}

void clear(int *testa,int *coda,int *cont,bool *codavuota) //funzione svuota vettore
{
    if (*codavuota==false) //se la coda non è già vuota..
    {
    *testa=-1; //testa e coda tornano a -1,ossia fuori dal vettore
    *coda=-1;
    *cont=0; //il contatore si azzera
    *codavuota=true; //la coda è vuota
    
    cout<<"Il buffer è stato svuotato"<<endl;
    }
    else
    cout<<"Il buffer è già vuoto"<<endl;
}
int main()
{
    int n;
    cout<<"Grandezza Buffer?"<<endl;
    check(&n);
    int head,tail=-1;
    int empty = 0;
    int vettore[n];
    int input;
    bool esci=false;
    bool codafull=false;
    bool codaempty=true;
    
     while (esci==false)
    {
        visualizzamenu();

        check(&input);
        switch (input) //Switch case dei vari input
        {
            case 1:
                    inqueue(vettore, n, &tail,&head, &empty, input,&codafull,&codaempty);
            break;
            case 2:
                    dequeue(vettore, n, &head,&tail, &empty, &codaempty,&codafull);
            break;
            case 3:
                    showvet(vettore, n, tail, empty,codaempty);
            break;
            case 4:
                esci=true;
            break;
               case 5:
               mostravet(vettore,tail,"Coda",codaempty);
            break;
             case 6:
               mostravet(vettore,head,"Testa",codaempty);
            break;
             case 7:
              bufferstatus(codaempty,"vuoto");
            break;
             case 8:
              bufferstatus(codafull,"pieno");
            break;
             case 9:
              clear(&head,&tail,&empty,&codaempty);
             break;
            default:
                 cout<<"Scelta errata"<<endl<<endl<<endl<<endl;
            break;
        }
}

cout<<"Sei uscito dal programma";


    return 0;
}

