/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

int main()
{
int dim=3;
struct oggetto
{
    string nome;
    int codice;
    int effetto;
} oggetti[dim] ;


oggetti[0].nome="Pozione";
oggetti[0].codice=1;
oggetti[0].effetto=+10;

oggetti[1].nome="HiPotion";
oggetti[1].codice=2;
oggetti[1].effetto=+20;



oggetti[2].nome="VitalityPotion";
oggetti[2].codice=3;
oggetti[2].effetto=+50;



int HP=5;
int MaxHP=100;
HP=HP+oggetti[1].effetto;
MaxHP=MaxHP+oggetti[2].effetto;

    for (int i=0;i<dim;i++)
    {
       cout<<oggetti[i].nome<<endl<<oggetti[i].codice<<endl<<oggetti[i].effetto<<endl;
    }
        return 0;

}
