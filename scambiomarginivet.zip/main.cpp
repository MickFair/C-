/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    srand(time(NULL));
    
    cout<<"Inserisci offset di grandezza vettore";
    int ranv;//Offset di grandezza random vet
    cin>>ranv;
    int n=(rand()%ranv+1);
    int v1[n];
    int temp=0;//Var temp per scambio
    cout<<"Inserisci offset di grandezza numeri";
    int offn; //Offset di grandezza random numeri
    cin>>offn;
    
        for (int i=0;i<n;i++) //Assegnazione numeri random a v1
    {
       v1[i]=(rand()%offn+1); 
       
    }
    
    cout<<"Vettore 1"<<endl; //Stampa v1
    
        for (int i=0;i<n;i++)
    {
        cout<<v1[i]<<" ";
    }
    
    cout<<endl;
    for (int i=0,j=n-1;((i<=j) and (j>=i));i++,j--) //Scambio v1[i] con v1[j],incrementa i,decrementa j fino a quando i e j non sono uguali o opposti
    {
    
        temp=v1[i];
        v1[i]=v1[j];
        v1[j]=temp;
    }
    
    cout<<"Vettore Scambiato"<<endl; //Stampa vettore scambiato
    
    for (int i=0;i<n;i++)
    {
        cout<<v1[i]<<" ";
    }
    return 0;
}