/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <ctime>
using namespace std;

int vetmax(int v[],int dim,int a)
{    
    int max=0;
    for (int i=0;i<dim;i++)
    {
        if (v[i]>max)
        {max=v[i];}
        
    }
    
    return max;
}

int vetmax2(int v[],int dim,int a)
{    
    int max2=0;
    for (int i=0;i<dim;i++)
    {
        if ((v[i]<a) and (v[i]>max2))
        {max2=v[i];}
        
    }
    
    return max2;
}
int vetmax3(int v[],int dim,int a)
{    
    int max3=0;
    for (int i=0;i<dim;i++)
    {
         if ((v[i]<a) and (v[i]>max3))
        {max3=v[i];}
    }
    
    return max3;
}
int check()
{
    int temp;
    cin>>temp;
    while ((cin.fail()) or (temp<1))
    {
        cin.clear();
        cin.ignore();
        cout<<"Errore,inserisci un numero valido"<<endl;
        cin>>temp;
        
    }
    return temp;
}
int main()
{
    int n; // Numero Partecipanti
    int c[3]; //Vettore [Classifica]
    int max=0; // Max Classifica [1]
    int max2=0; // Max Classifica [2]
    int max3=0; // Max Classifica [3]
    int ran=0; //Range di numeri da 0 a X
    
    cout<<"Quanti partecipanti?"<<endl;
    n=check();
    int p[n]; // Vettore [Partecipanti]
    
    cout<<"Numeri casuali da 1 a...?"<<endl;
    ran=check();
    
    while (n>ran)
    {
        cout<<"Errore."<<endl;
            cout<<"al fine di evitare doppioni,i partecipanti non possono essere superiori al range di numeri"<<endl;
                cout<<"Per favore,inserisci un numero di partecipanti valido"<<endl;
                n=check();
                  cout<<"Inserisci il range di numeri casuali da 1 a...?"<<endl;
                   ran=check();

    }
   
    srand(time(NULL)); // Seme funzione rand() vettore p[i]
    
    for (int i=0;i<n;i++)
    {
       p[i]=(rand()%ran+1); //Numeri random fino a X,variabili
       
       for(int j=0;j<i;j++) 
       {
       	if(p[i]==p[j]) {
           i--;
           break;
        }
       }
       
    }
          cout<<"Tutti i partecipanti sono i numeri: "<<endl;;
      
    for (int i=0;i<n;i++)
    {
        cout<<p[i]<<" ";
    }
    
    cout<<""<<endl;
    //Funzioni per i 3 massimi
        max=vetmax(p,n,max);
        max2=vetmax2(p,n,max);
        max3=vetmax3(p,n,max2);

//Assegnazione 3 massimi ai 3 indici

for (int i=0;i<3;i++)
{   
    c[i]=max;
    if (i=1)
    {c[i]=max2;}
    if (i=2)
    {c[i]=max3;}

}

//Output valore in indice corrispondente

 for (int i=0;i<3;i++) { 
 cout<<"Al primo posto si classifica il numero "<<c[i]<<endl;
     if (i=1)
     {cout<<"Al secondo "<<c[i]<<endl;}
     if (i=2)
     {cout<<"Al terzo "<<c[i]<<endl;}
 }

    return 0;
}


