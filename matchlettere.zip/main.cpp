/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    string v1[7]={"M","I","C","H","E","L","E"};
    string v2[7]={"M","I","C","H","E","L","I"};
    bool mismatch=false;
    int i=0;
    
    while ((i<7) and (mismatch==false))
    {
        if (v1[i]==v2[i])
            {
                i++;
            }    
        else
            mismatch=true;
    }
    
    if (mismatch==true)
        cout<<"Le lettere sono diverse";
    else
        cout<<"Le lettere sono uguali";
    return 0;
}