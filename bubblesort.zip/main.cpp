/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

void stampavet(int v[],int dim)
{
    for (int i=0;i<dim;i++)
        {
         cout<<v[i]<<" ";
        }
     
}

void scambia (int vet[],int dim,int pos)
{
    int temp=0;
    
    temp=vet[pos];
    vet[pos]=vet[pos+1];
    vet[pos+1]=temp;
        
}

void bubblesort (int dim,int dim2,int vet[])
{
        for (int j=0;j<dim;j++)
    {
        for (int i=0;i<dim;i++)
        {
            if (vet[i]>vet[i+1])
            {
            scambia(vet,dim,i);
            }
        }
    dim2=dim2-1;
    }  
}
int main()
{
    int n=25;
    int vett[n];
    int v=n;
    int ran=50;
    
    srand(time(NULL)); // Seme funzione rand() vettore p[i]
    
    for (int i=0;i<n;i++)
    {
       vett[i]=(rand()%ran+1); //Numeri random fino a X,variabili
       
       for(int j=0;j<i;j++) 
       {
       	if(vett[i]==vett[j]) 
       	{
           i--;
        }
       }
    }   
stampavet(vett,n);
cout<<""<<endl;
cout<<"Passo"<<endl;

// inizio ordinamento
    bubblesort(n,v,vett);
    
stampavet(vett,n);

    return 0;
}
